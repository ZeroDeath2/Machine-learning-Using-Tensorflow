# Gadgets > 2023-05-23 1:59pm
https://universe.roboflow.com/internship-vwhrl/gadgets-lzfqu

Provided by a Roboflow user
License: CC BY 4.0

